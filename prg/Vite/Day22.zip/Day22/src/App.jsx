import React from 'react'
import Recipes from './component/Recipes'

const App = () => {
  return (
   <>
   <Recipes/>
   </>
  )
}

export default App