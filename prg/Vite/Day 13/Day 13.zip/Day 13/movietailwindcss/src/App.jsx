import HomePage from "./Pages/Homepage";

function App() {
  return (
    <>
      <div>
        <HomePage />
      </div>
    </>
  );
}

export default App;
